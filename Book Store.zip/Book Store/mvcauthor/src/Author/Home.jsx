import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function Home() {
    const [authors, setAuthors] = useState([]);
    const [form, setForm] = useState({ name: '', email: '', books: '' });
    const [editId, setEditId] = useState(null);

    const API_URL = "http://localhost:9876/user"

    useEffect(() => {
        fetchAuthors();
    }, []);

    const fetchAuthors = async () => {
        try {
            const response = await axios.get(API_URL);
            setAuthors(response.data);
        } catch (error) {
            console.error("Error fetching authors:", error);
        }
    };

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (editId) {
                await axios.patch(`${API_URL}/${editId}`, form);
            } else {
                await axios.post(API_URL, form);
            }
            setForm({ name: '', email: '', books: '' });
            setEditId(null);
            fetchAuthors();
        } catch (error) {
            console.error("Error saving author:", error);
        }
    };

    const handleEdit = (author) => {
        setForm({ name: author.name, email: author.email, books: author.books });
        setEditId(author._id);
    };

    const handleDelete = async (id) => {
        try {
            await axios.delete(`${API_URL}/${id}`);
            fetchAuthors();
        } catch (error) {
            console.error("Error deleting author:", error);
        }
    };

    return (
        <div style={{ maxWidth: "800px", margin: "50px auto", padding: "20px", boxShadow: "0 0 10px rgba(0,0,0,0.1)", borderRadius: "8px" }}>
            <h2 style={{ textAlign: "center", marginBottom: "20px" }}>Author Management</h2>

            <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "10px", marginBottom: "30px" }}>
                <input
                    type="text"
                    name="name"
                    placeholder="Author Name"
                    value={form.name}
                    onChange={handleChange}
                    required
                />
                <input
                    type="email"
                    name="email"
                    placeholder="Author Email"
                    value={form.email}
                    onChange={handleChange}
                    required
                />
                <input
                    type="text"
                    name="books"
                    placeholder="Books Written"
                    value={form.books}
                    onChange={handleChange}
                    required
                />
                <button type="submit" style={{ padding: "10px", backgroundColor: "#4CAF50", color: "white", border: "none", cursor: "pointer" }}>
                    {editId ? "Update Author" : "Add Author"}
                </button>
            </form>

            <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                    <tr style={{ backgroundColor: "#f2f2f2" }}>
                        <th style={{ border: "1px solid #ddd", padding: "8px" }}>Name</th>
                        <th style={{ border: "1px solid #ddd", padding: "8px" }}>Email</th>
                        <th style={{ border: "1px solid #ddd", padding: "8px" }}>Books</th>
                        <th style={{ border: "1px solid #ddd", padding: "8px" }}>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {authors.map((author) => (
                        <tr key={author._id}>
                            <td style={{ border: "1px solid #ddd", padding: "8px" }}>{author.name}</td>
                            <td style={{ border: "1px solid #ddd", padding: "8px" }}>{author.email}</td>
                            <td style={{ border: "1px solid #ddd", padding: "8px" }}>{author.books}</td>
                            <td style={{ border: "1px solid #ddd", padding: "8px" }}>
                                <button onClick={() => handleEdit(author)} style={{ marginRight: "10px", padding: "5px 10px", backgroundColor: "#2196F3", color: "white", border: "none" }}>
                                    Edit
                                </button>
                                <button onClick={() => handleDelete(author._id)} style={{ padding: "5px 10px", backgroundColor: "#f44336", color: "white", border: "none" }}>
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
