const express = require("express")
const { adduser, getuser } = require("../controller/userController")

const router = express.Router()
router.post("/add", adduser)
router.get("/", getuser)

module.exports = router