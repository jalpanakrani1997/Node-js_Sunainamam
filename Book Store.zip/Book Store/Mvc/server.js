const express = require("express")
const db = require("./config/db")
const router = require("./routes/userRoute")
const cors = require("cors")
const app = express()
app.use(express.json())

app.use(cors())


app.use("/user", router)
app.listen(9876, () => {
    console.log("server is running on  http://localhost:9876")
})