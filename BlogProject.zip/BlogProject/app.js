// // const express = require("express")
// // const db = require("./config/db")
// // const userModel = require("./model/userModel")
// // const multer = require("multer")
// // const path = require("path")
// // // const { fstat } = require("fs")
// // const fs = require("fs");

// // const app = express()

// // app.set("view engine", "ejs")
// // app.use(express.json())
// // app.use(express.urlencoded())
// // app.use('/uploads', express.static(path.join(__dirname, 'uploads')))

// // const storage = multer.diskStorage({
// //     destination: function (req, file, cb) {
// //         cb(null, 'uploads')
// //     },
// //     filename: function (req, file, cb) {
// //         cb(null, file.originalname)
// //     }
// // })

// // const upload = multer({ storage: storage }).single("image")

// // app.post("/add", upload, async (req, res) => {
// //     const { username, password } = req.body
// //     let image = ""
// //     if (req.file) {
// //         image = req.file.path
// //     }
// //     const data = await userModel.create({
// //         username: username,
// //         password: password,
// //         image: image
// //     })
// //     return res.redirect("/")
// // })

// // app.get("/", async (req, res) => {
// //     const data = await userModel.find()
// //     res.render("home", { data, editUser: null })
// // })

// // app.get("/edit/:id", async (req, res) => {
// //     const data = await userModel.find()
// //     const editUser = await userModel.findById(req.params.id)
// //     res.render("home", { data, editUser })
// // })

// // app.post("/update/:id", upload, async (req, res) => {
// //     const { username, password } = req.body
// //     const user = await userModel.findById(req.params.id)
// //     let updateData = { username: username, password: password }

// //     if (req.file) {
// //         if (user && user.image) {
// //             fs.unlink(user.image, () => {
// //                 console.log("Old image unlinked successfully.", user.image);
// //             })
// //         }
// //         updateData.image = req.file.path
// //     }

// //     await userModel.findByIdAndUpdate(req.params.id, updateData)
// //     res.redirect("/")
// // })

// // app.get("/delete", async (req, res) => {
// //     const id = req.query.id
// //     const user = await userModel.findById(id)

// //     if (user && user.image) {
// //         fs.unlink(user.image, () => {

// //             console.log("Image deleted successfully.", user.image);

// //         })
// //     }
// //     await userModel.findByIdAndDelete(id)
// //     res.redirect("/")
// // })

// // app.listen(8800, () => {
// //     console.log("server listen http://localhost:8800")
// // })


// const express = require("express");
// const path = require("path");
// const app = express();
// const userRoutes = require("./routes/userRoutes");
// require("./config/db");

// app.set("view engine", "ejs");
// app.use(express.urlencoded({ extended: true }));
// app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// app.use("/", userRoutes);

// app.listen(8800, () => {
//     console.log("Server running at http://localhost:8800");
// });



const express = require("express");
const path = require("path");
const session = require("express-session");
const app = express();

const userRoutes = require("./routes/userRoutes");
const authRoutes = require("./routes/authRoutes");

require("./config/db");

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use(session({
    secret: "b1e0be1f3af8570209daea3096d1e029f7d3816fa0705e9d312b33847ce25654b8abf3cc012ac848bdb1f79468ca3fdf5ef18fed480f2b6c783df5a95edc0cbc",
    resave: false,
    saveUninitialized: false
}));
app.use((req, res, next) => {
    res.locals.user = req.session.user;
    next();
});

// // Expose session to views
// app.use((req, res, next) => {
//     res.locals.session = req.session;
//     next();
// });

app.use("/", authRoutes); // Signup/Login/Logout
app.use("/", userRoutes); // Blog routes

app.listen(8800, () => {
    console.log("Server running at http://localhost:8800");
});
