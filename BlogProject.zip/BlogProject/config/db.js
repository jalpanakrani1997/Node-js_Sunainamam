// // const mongoose = require("mongoose")

// // mongoose.connect("mongodb+srv://jalpanakrani:jalpa1997@cluster0.r01ye.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

// // const db = mongoose.connection

// // db.on("connected", (err, data) => {
// //     if (err) {
// //         console.log(err)
// //     } else {
// //         console.log("connected to database")
// //     }
// // })



const mongoose = require("mongoose")

mongoose.connect("mongodb://localhost:27017/nodeMongoose")

const db = mongoose.connection

db.on("connected", (err, data) => {
    if (err) {
        console.log(err)
    } else {
        console.log("connected to database")
    }
})


// const mongoose = require("mongoose")

// mongoose.connect("mongodb+srv://jalpanakrani1997:jalpa1997@cluster0.1qif6w9.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0/nodeMongoose")

// const db = mongoose.connection

// db.on("connected", (err, data) => {
//     if (err) {
//         console.log(err)
//     } else {
//         console.log("connected to database")
//     }
// })
