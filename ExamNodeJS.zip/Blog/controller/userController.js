const userModel = require("../model/userModel");
const fs = require("fs");
const path = require("path");
const Blog = require("../model/blogModel");

exports.getHome = async (req, res) => {
    try {
        // Check if user is logged in
        if (!req.session.user) {
            return res.redirect('/login');
        }

        // Get only the logged-in user's blogs
        const data = await Blog.find({ author: req.session.user._id }).sort({ createdAt: -1 });
        res.render("home", { data, editUser: null, user: req.session.user });
    } catch (error) {
        console.error('Error fetching blogs:', error);
        res.status(500).send("Error fetching blogs");
    }
};

exports.addUser = async (req, res) => {
    try {
        const { username, description } = req.body;
        
        // Handle image upload
        let image = "";
        if (req.file) {
            // Create uploads directory if it doesn't exist
            const uploadsDir = path.join(__dirname, '../uploads');
            if (!fs.existsSync(uploadsDir)) {
                fs.mkdirSync(uploadsDir, { recursive: true });
            }
            
            // Move the uploaded file to uploads directory
            const oldPath = req.file.path;
            const newPath = path.join(uploadsDir, req.file.filename);
            fs.renameSync(oldPath, newPath);
            image = 'uploads/' + req.file.filename;
        }
        
        // Add the current user as the author
        await Blog.create({
            username,
            description,
            image,
            author: req.session.user._id
        });
        
        res.redirect("/");
    } catch (error) {
        console.error('Error adding blog:', error);
        res.status(500).send("Error adding blog");
    }
};

exports.editUser = async (req, res) => {
    try {
        // Check if user is logged in
        if (!req.session.user) {
            return res.redirect('/login');
        }

        // Only allow editing if the blog belongs to the current user
        const editUser = await Blog.findOne({
            _id: req.params.id,
            author: req.session.user._id
        });

        if (!editUser) {
            return res.status(403).send("Not authorized to edit this blog");
        }

        // Get only the logged-in user's blogs
        const data = await Blog.find({ author: req.session.user._id }).sort({ createdAt: -1 });
        res.render("home", { data, editUser, user: req.session.user });
    } catch (error) {
        console.error('Error editing blog:', error);
        res.status(500).send("Error editing blog");
    }
};

exports.updateUser = async (req, res) => {
    try {
        const { username, description } = req.body;
        
        // Only allow updating if the blog belongs to the current user
        const blog = await Blog.findOne({
            _id: req.params.id,
            author: req.session.user._id
        });

        if (!blog) {
            return res.status(403).send("Not authorized to update this blog");
        }

        let updateData = { username, description };

        if (req.file) {
            // Create uploads directory if it doesn't exist
            const uploadsDir = path.join(__dirname, '../uploads');
            if (!fs.existsSync(uploadsDir)) {
                fs.mkdirSync(uploadsDir, { recursive: true });
            }

            // Delete old image if it exists
            if (blog.image) {
                const oldImagePath = path.join(__dirname, '..', blog.image);
                if (fs.existsSync(oldImagePath)) {
                    fs.unlinkSync(oldImagePath);
                }
            }

            // Move the new uploaded file to uploads directory
            const oldPath = req.file.path;
            const newPath = path.join(uploadsDir, req.file.filename);
            fs.renameSync(oldPath, newPath);
            updateData.image = 'uploads/' + req.file.filename;
        }

        await Blog.findByIdAndUpdate(req.params.id, updateData);
        res.redirect("/");
    } catch (error) {
        console.error('Error updating blog:', error);
        res.status(500).send("Error updating blog");
    }
};

exports.deleteUser = async (req, res) => {
    try {
        const id = req.query.id;
        
        // Only allow deletion if the blog belongs to the current user
        const blog = await Blog.findOne({
            _id: id,
            author: req.session.user._id
        });

        if (!blog) {
            return res.status(403).send("Not authorized to delete this blog");
        }

        // Delete the image file if it exists
        if (blog.image) {
            const imagePath = path.join(__dirname, '..', blog.image);
            if (fs.existsSync(imagePath)) {
                fs.unlinkSync(imagePath);
            }
        }

        await Blog.findByIdAndDelete(id);
        res.redirect("/");
    } catch (error) {
        console.error('Error deleting blog:', error);
        res.status(500).send("Error deleting blog");
    }
};

exports.loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await userModel.findOne({ email });

        if (!user || user.password !== password) {
            return res.render('login', { error: 'Invalid email or password' });
        }

        // Store user info in session
        req.session.user = {
            _id: user._id,
            name: user.name,
            email: user.email
        };

        // Save session before redirecting
        req.session.save((err) => {
            if (err) {
                console.error('Session save error:', err);
                return res.status(500).send('Error during login');
            }
            res.redirect('/');
        });
    } catch (error) {
        console.error('Error in login:', error);
        res.status(500).send('Error during login');
    }
};

exports.getAllBlogs = async (req, res) => {
    try {
        // Check if user is logged in
        if (!req.session.user) {
            return res.redirect('/login');
        }

        // Get only the logged-in user's blogs
        const blogs = await Blog.find({ author: req.session.user._id }).sort({ createdAt: -1 });
        res.render('allblogs', {
            blogs,
            user: req.session.user
        });
    } catch (error) {
        console.error('Error fetching all blogs:', error);
        res.status(500).send('Error fetching blogs');
    }
};
