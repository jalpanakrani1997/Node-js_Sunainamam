const AuthModel = require("../model/authModel");

exports.signup = async (req, res) => {
    try {
        const { name, email, password, confirm_password } = req.body;
        
        // Check if passwords match
        if (password !== confirm_password) {
            return res.render('signup', { error: 'Passwords do not match' });
        }

        // Check if user already exists
        const existing = await AuthModel.findOne({ email });
        if (existing) {
            return res.render('signup', { error: 'User already exists' });
        }

        // Create new user
        await AuthModel.create({ name, email, password });
        
        // Redirect to login page
        res.redirect("/login");
    } catch (error) {
        console.error('Signup error:', error);
        res.render('signup', { error: 'An error occurred during signup' });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await AuthModel.findOne({ email, password });
        
        if (!user) {
            return res.render('login', { error: 'Invalid email or password' });
        }

        // Store complete user information in session
        req.session.user = {
            _id: user._id,
            name: user.name,
            email: user.email
        };

        res.redirect("/");
    } catch (error) {
        console.error('Login error:', error);
        res.render('login', { error: 'An error occurred during login' });
    }
};

exports.logout = (req, res) => {
    req.session.destroy(err => {
      if (err) return res.send("Error logging out.");
      res.redirect("/login");
    });
};
