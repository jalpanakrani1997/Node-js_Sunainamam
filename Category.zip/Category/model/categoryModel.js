const mongoose = require("mongoose")

const categorySchema = new mongoose.Schema({
    title:"String",
    description:"String",
    price:"number",
    image:"String",
    subcategoryId: { type: mongoose.Schema.Types.ObjectId, ref: "subcategory"},
})

const categoryModel = mongoose.model("category",categorySchema)
module.exports= categoryModel