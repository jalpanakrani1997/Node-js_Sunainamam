const mongoose = require("mongoose")

const extracategorySchema = new mongoose.Schema({
    title:"String",
    price:"number",
    image:"String",
})

const extracategoryModel = mongoose.model("extracategory",extracategorySchema)
module.exports= extracategoryModel