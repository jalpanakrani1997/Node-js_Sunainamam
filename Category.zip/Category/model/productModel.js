const mongoose = require("mongoose")

const productSchema = new mongoose.Schema({
    title:"String",
    description:"String",
    price:"number",
    image:"String",
    categoryId : { type:mongoose.Schema.Types.ObjectId, ref:"category"},
    subcategoryId:{type : mongoose.Schema.Types.ObjectId, ref:"subcategory"},
    extracategoryId:{type:mongoose.Schema.Types.ObjectId,ref:"extracategory"},
})

const productModel =  mongoose.model("product",productSchema)
module.exports= productModel


    