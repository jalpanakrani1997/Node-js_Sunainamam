const mongoose = require("mongoose")

const subcategorySchema = new mongoose.Schema({
    title:"String",
    price:"number",
    image:"String",
    extracategoryId:{type:mongoose.Schema.Types.ObjectId,ref:"extracategory"}
})

const subcategoryModel = mongoose.model("subcategory",subcategorySchema)
module.exports= subcategoryModel