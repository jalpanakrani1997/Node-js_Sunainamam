const express = require("express")
const db = require("./config/db")
const productModel = require("./model/productModel")
const P_router = require("./router/ProductRouter")
const C_router = require("./router/categoryRouter")
const S_router = require("./router/subcategoryRouter")
const E_router = require("./router/extracategoryRouter")
const app = express()

app.use(express.json())

app.use("/product",P_router)
app.use("/category",C_router)
app.use("/subcategory",S_router)
app.use("/extracategory",E_router)
app.listen(8008,()=>{
    console.log("server running  http://localhost:8008");
})