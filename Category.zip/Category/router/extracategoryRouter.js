const express = require("express")
const { E_data, create, deleteCategory, editCategory } = require("../controller/extracategoryController")



const E_router = express.Router()

E_router.get("/",E_data)
E_router.post("/create",create)
E_router.delete("/delete/:id",deleteCategory)
E_router.patch("/edit/:id",editCategory)

module.exports=E_router