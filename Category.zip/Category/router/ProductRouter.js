const express = require("express")
const { P_data, create, deleteProduct, editProduct } = require("../controller/ProductController")

const P_router = express.Router()

P_router.get("/",P_data)
P_router.post("/create",create)
P_router.delete("/delete/:id",deleteProduct)
P_router.patch("/edit/:id",editProduct)

module.exports=P_router