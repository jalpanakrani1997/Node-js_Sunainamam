const express = require("express")
const { C_data,create, deleteCategory, editCategory } = require("../controller/categoryController")

const C_router = express.Router()

C_router.get("/",C_data)
C_router.post("/create",create)
C_router.delete("/delete/:id",deleteCategory)
C_router.patch("/edit/:id",editCategory)

module.exports=C_router