const express = require("express")
const { S_data,create,deleteCategory,editCategory} = require("../controller/subcategoryController")


const S_router = express.Router()

S_router.get("/",S_data)
S_router.post("/create",create)
S_router.delete("/delete/:id",deleteCategory)
S_router.patch("/edit/:id",editCategory)

module.exports=S_router