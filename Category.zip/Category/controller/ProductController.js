const productModel = require("../model/productModel")

const P_data = async (req, res) => {
    // let data = await productModel.find().populate("categoryId").populate("subcategoryId").populate("extracategoryId")


    let data = await productModel.find().populate({ path: "categoryId", populate: { path: "subcategoryId", populate: { path: "extracategoryId" } } })

 
    // const products = await productModel.find().populate({ path: "categoryId", populate: { path: "subcategoryId", populate: { path: "extracategoryId" } } });


    res.send(data)
}

const create = async (req, res) => {
    let data = await productModel.create(req.body)
    res.send(data)
}

const deleteProduct = async (req, res) => {
    const { id } = req.params
    let data = await productModel.findByIdAndDelete(id)
    res.send(data)
}

const editProduct = async (req, res) => {
    const { id } = req.params
    let data = await productModel.findByIdAndUpdate(id, req.body)
    res.send(data)
}

module.exports = { P_data, create, deleteProduct, editProduct }

