const subcategoryModel = require("../model/subcategoryModel")


const S_data = async (req,res)=>{
    let data = await subcategoryModel.find().populate("extracategoryId")
    res.send(data)
}

const create = async (req,res) => {
    let data = await subcategoryModel.create(req.body)
    res.send(data)
}

const deleteCategory = async (req,res) =>{
    const { id } = req.params;
    let data = await subcategoryModel.findByIdAndDelete(id)
    res.send(data)
}

const editCategory = async (req,res) =>{
    const { id } = req.params;
    let data = await subcategoryModel.findByIdAndUpdate(id, req.body)
    res.send(data)
}

module.exports={S_data,create,deleteCategory,editCategory}