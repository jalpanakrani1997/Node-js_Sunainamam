const categoryModel = require("../model/categoryModel")

const C_data = async (req, res) => {
    let data = await categoryModel.find().populate({ path: "subcategoryId", populate: { path: "extracategoryId" } })
 




    // let data = await productModel.find().populate({ path: "categoryId", populate: { path: "subcategoryId", populate: { path: "extracategoryId" } } })





res.send(data)
}

const create = async (req, res) => {
    let data = await categoryModel.create(req.body)
    res.send(data)
}

const deleteCategory = async (req, res) => {
    const { id } = req.params;
    let data = await categoryModel.findByIdAndDelete(id)
    res.send(data)
}

const editCategory = async (req, res) => {
    const { id } = req.params;
    let data = await categoryModel.findByIdAndUpdate(id, req.body)
    res.send(data)
}

module.exports = { C_data, create, deleteCategory, editCategory }