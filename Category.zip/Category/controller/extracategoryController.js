const extracategoryModel = require("../model/extracategoryModel")

const E_data = async (req,res)=>{
    let data = await extracategoryModel.find()
    res.send(data)
}

const create = async (req,res) => {
    let data = await extracategoryModel.create(req.body)
    res.send(data)
}

const deleteCategory = async (req,res) =>{
    const { id } = req.params;
    let data = await extracategoryModel.findByIdAndDelete(id)
    res.send(data)
}

const editCategory = async (req,res) =>{
    const { id } = req.params;
    let data = await extracategoryModel.findByIdAndUpdate(id, req.body)
    res.send(data)
}

module.exports={E_data,create,deleteCategory,editCategory}