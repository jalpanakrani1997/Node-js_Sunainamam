const express = require("express");
const passport = require("passport");
const userModel = require("../model/userModel");

const router = express.Router();

// Show signup page
router.get("/signup", (req, res) => {
  res.render("signup", { message: "" });
});

// Handle signup form
router.post("/signup", async (req, res) => {
  const { username, password } = req.body;
  try {
    const existingUser = await userModel.findOne({ username });
    if (existingUser) {
      return res.render("signup", { message: "User already exists" });
    }

    await userModel.create({ username, password });
    res.redirect("/user/login");
  } catch (err) {
    console.error("Signup error:", err);
    res.render("signup", { message: "Error during signup" });
  }
});

// Show login page
router.get("/login", (req, res) => {
  res.render("Login", { message: "" }); // ✅ Fix here
});

// Handle login form
router.post("/local", (req, res, next) => {
  passport.authenticate("local", (err, user, info) => {
    if (err) return next(err);

    if (!user) {
      return res.render("Login", { message: info.message || "Login failed" });
    }

    req.logIn(user, (err) => {
      if (err) return next(err);
      return res.redirect("/blog");
    });
  })(req, res, next);
});

// Handle logout
router.get("/logout", (req, res) => {
  req.logout((err) => {
    if (err) {
      console.error("Error logging out user:", err);
    }
    res.redirect("/user/login");
  });
});

module.exports = router;
