const express = require("express");
const {
    addBlog, getBlogs, getBlogById, updateBlog, deleteBlog
} = require("../controller/blogController");
const ensureAuth = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/add", ensureAuth, addBlog);
router.get("/", getBlogs);
router.get("/:id", getBlogById);
router.put("/update/:id", ensureAuth, updateBlog);
router.delete("/delete/:id", ensureAuth, deleteBlog);

module.exports = router;
