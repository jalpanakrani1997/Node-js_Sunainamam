const express = require("express");
const session = require("express-session");
const passport = require("passport");
const cors = require("cors");
const localAuth = require("./middleware/LocalAuth");
const router = require("./routes/userRoute");
require("./config/db")

const app = express();

const posts = [];

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cors());

app.use(
    session({
        secret: "keyboard cat",
        resave: false,
        saveUninitialized: true,
    })
);

app.use(passport.initialize());
app.use(passport.session());
localAuth(passport);

app.get("/", (req, res) => {
    res.redirect("/user/signup");
});

app.get("/signup", (req, res) => {
    res.render("Signup");
});

app.get("/login", (req, res) => {
    res.render("Login");
});

function ensureAuthenticated(req, res, next) {
    if (req.isAuthenticated()) return next();
    res.redirect("/login");
}

app.get("/blog", ensureAuthenticated, (req, res) => {
    res.render("blog", {
        user: req.user,
        posts,
    });
});

app.post("/blog/create", ensureAuthenticated, (req, res) => {
    const { title, content } = req.body;

    posts.unshift({
        title,
        content,
        author: req.user.username,
    });

    res.redirect("/blog");
});

app.use("/user", router);

app.listen(9000, () => {
    console.log("Server running on http://localhost:9000");
});
