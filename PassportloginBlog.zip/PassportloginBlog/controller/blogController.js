const blogModel = require("../model/blogModel");

const addBlog = (req, res) => {
    blogModel.create({ ...req.body, author: req.user._id }).then(data => res.send(data));
};

const getBlogs = (req, res) => {
    blogModel.find().populate("author", "username").then(data => res.send(data));
};

const getBlogById = (req, res) => {
    blogModel.findById(req.params.id).then(data => res.send(data));
};

const updateBlog = (req, res) => {
    blogModel.findByIdAndUpdate(req.params.id, req.body, { new: true }).then(data => res.send(data));
};

const deleteBlog = (req, res) => {
    blogModel.findByIdAndDelete(req.params.id).then(data => res.send({ message: "Deleted", data }));
};

module.exports = { addBlog, getBlogs, getBlogById, updateBlog, deleteBlog };
