import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import MovieForm from './movieName/MovieForm';

function App() {
  return (
    <div className="App">
      <MovieForm />
    </div>
  );
}

export default App;
