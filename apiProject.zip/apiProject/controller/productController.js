const { model } = require("mongoose")
const productModel = require("../model/productModel")

const addproduct = async (req,res)=>{
    const data = await productModel.create(req.body)
    res.send(data)
}

const getproduct = async (req,res)=>{
    const data = await productModel.find()
    res.send(data)
}

const deleteproduct = async (req,res) =>{
    const {id} = req.params.id
    const data = await productModel.findByIdAndDelete(id)
    res.send(data)
}

const editproduct = async (req,res) =>{
    const {id} = req.params.id
    const data = await productModel.findByIdAndEdit(id)
    res.send(data)
}

module.exports = {addproduct,getproduct,deleteproduct,editproduct}
