const userModel = require("../model/userModel")
const jwt = require("jsonwebtoken")

const adduser = async(req,res)=>{
    const {username,password,role}=req.body
    const data = await userModel.create({
        username:username,
        password:password,
        role:role || "user"
    })
    res.send(data)
}

const getuser = async (req,res)=>{
    const data = await userModel.find()
    res.send(data)
}

const login = async (req,res)=>{
    const {username,password,role}=req.body;

    const data = await userModel.findOne({username})
    if(!data){
        return res.send("username not exist")
    }
    else if(data.password!==password){
        return res.send("password mismatch")
    }
    else{
        let payload = {
            username,password,role
        }
        const token = jwt.sign(payload,"secret key")

        return res.send(token)
    }
}

const verifyToken = (req,res,next)=>{
    const token = req.headers.authorization?.split(" ")[1]

    const data = jwt.verify(token,"secret key")
    req.user=data
    next()
}

module.exports ={adduser,getuser,login,verifyToken}