const mongoose = require("mongoose")

const producSchema = new mongoose.Schema({
    title:String,
    decription:String,
    price:Number,
    image:String
})

const productModel = new mongoose.model("product",producSchema)
module.exports = productModel; 