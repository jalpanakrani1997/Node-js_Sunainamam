const Check = (req,res,next)=>{
    if(req.user.role!="Admin"){
        res.send("Admin Only")
    }
    else{
        next()
    }
}

module.exports = Check