const express = require("express")
const { addproduct, getproduct, deleteproduct, editproduct } = require("../controller/productController")

const P_routes = express.Router()


P_routes.post("/add",addproduct)
P_routes.get("/",getproduct)
P_routes.delete("/delete/:id",deleteproduct)
P_routes.patch("edit/:id",editproduct)

module.exports = P_routes