const express = require("express")
const { adduser, getuser, login,verifyToken } = require("../controller/userController")
const router = express.Router()

router.post("/add",adduser)
router.get("/",getuser)
router.post("/login",login)
router.post("/token",verifyToken)

module.exports = router