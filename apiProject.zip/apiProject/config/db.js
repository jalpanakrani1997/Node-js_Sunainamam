const mongoose = require("mongoose")

mongoose.connect("mongodb+srv://jinaljasani31:jinal123@cluster0.owj1r.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

const db = mongoose.connection

db.on("connected",(err,data)=>{
    if(err){
        console.log(err);
    }
    else{
        console.log("connected to data");
    }
})