const express = require("express")
const db = require("./config/db")
const router = require("./routes/usrRoute")
const P_routes = require("./routes/productRoute")
const app = express()

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/user",router)
app.use("/product",P_routes)
app.listen(9070,()=>{
    console.log("server running");
})