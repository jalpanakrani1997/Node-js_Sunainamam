const mongoose = require("mongoose")

const userSchema = new mongoose.Schema({
    category: {
        type: String
    }, title: {
        type: String
    }, price: {
        type: String
    }, description: {
        type: String
    }
})

const userModel = new mongoose.model("user", userSchema)
module.exports = userModel