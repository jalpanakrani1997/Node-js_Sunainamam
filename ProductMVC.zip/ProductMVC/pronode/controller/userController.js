const userModel = require("../model/userModel")

const adduser = async (req, res) => {
    const data = await userModel.create(req.body)
    res.send(data)
}
const getuser = async (req, res) => {
    const data = await userModel.find()
    res.send(data)
}
const deleteuser = async (req, res) => {
    const id = req.params.id
    const data = await userModel.findByIdAndDelete(id)
    res.send("sucess")
}
const updateuser = async (req, res) => {
    const id = req.params.id
    // const data = await userModel.findByIdAndUpdate(id)
    const data = await userModel.findByIdAndUpdate(id, req.body, { new: true });
    res.send(data)
}

module.exports = { adduser, getuser, deleteuser, updateuser }