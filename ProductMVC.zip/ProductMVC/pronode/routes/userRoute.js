const express = require("express")
const { adduser, getuser, deleteuser, updateuser } = require("../controller/userController")

const router = express.Router()
router.post("/", adduser)
router.get("/", getuser)
router.delete("/:id",deleteuser)
router.patch("/:id", updateuser)

module.exports = router