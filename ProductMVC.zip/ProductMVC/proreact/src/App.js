import logo from './logo.svg';
import './App.css';
import Product from './ProductPage/Product';

function App() {
  return (
    <div >
      <Product/>
    </div>
  );
}

export default App;
