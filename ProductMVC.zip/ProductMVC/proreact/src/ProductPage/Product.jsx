import React, { useState, useEffect } from "react";
import axios from "axios";

const Product = () => {
    const [products, setProducts] = useState([]);
    const [selectedProduct, setSelectedProduct] = useState(null);

    // Fetch product data from API
    useEffect(() => {
        // axios.get("https://fakestoreapi.com/products")
        axios.get("http://localhost:8765/user")
            .then((response) => setProducts(response.data))
            .catch((error) => console.error("Error fetching products:", error));
    }, []);

    return (
        <div style={{ display: "flex", padding: "20px", gap: "20px" }}>
            {/* Product List */}
            <div style={{ flex: 2 }}>
                <h2>Products</h2>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "20px" }}>
                    {products.map((product) => (
                        <div
                            key={product.id}
                            onClick={() => setSelectedProduct(product)}
                            style={{
                                border: "1px solid #ccc",
                                padding: "10px",
                                borderRadius: "10px",
                                cursor: "pointer",
                                textAlign: "center"
                            }}
                        >
                            <p><b>{product.category}</b></p>
                            {/* <img src={product.image} alt={product.title} style={{ width: "100px", height: "100px", objectFit: "contain" }} /> */}
                            <h4>{product.title}</h4>
                            <p>${product.price}</p>
                            <p>{product.description}</p>
                        </div>
                    ))}
                </div>
            </div>

            {/* Product Details */}
            {/* <div style={{ flex: 1 }}>
                {selectedProduct ? (
                    <div style={{ border: "1px solid #ccc", padding: "20px", borderRadius: "10px" }}>
                        <h2>{selectedProduct.title}</h2>
                        <img src={selectedProduct.image} alt={selectedProduct.title} style={{ width: "150px", height: "150px", objectFit: "contain" }} />
                        <p><strong>Price:</strong> ${selectedProduct.price}</p>
                        <p><strong>Description:</strong> {selectedProduct.description}</p>
                        <p><strong>Category:</strong> {selectedProduct.category}</p>
                    </div>
                ) : (
                    <h3>Click on a product to see details</h3>
                )}
            </div> */}
        </div>
    );
};

export default Product;
