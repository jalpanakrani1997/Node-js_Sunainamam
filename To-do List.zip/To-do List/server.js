const express = require("express")
const app = express()

app.use(express.urlencoded())
app.set("view engine", "ejs")

let student = [{ id: 1, name: "Jalpa" }]

app.post("/insertData", (req, res) => {
    let { id, name } = req.body
    id = Number(id)
    let obj = { id, name }
    student.push(obj)
    res.redirect("/")
})

app.get("/delete", (req, res) => {
    let id = Number(req.query.id)
    student = student.filter((el) => el.id !== id)
    res.redirect("/")
})

app.get("/editData", (req, res) => {
    let id = Number(req.query.id)
    let editStudent = student.find((el) => el.id === id)
    res.render("home", { student, editStudent })
})

app.post("/updateData", (req, res) => {
    let { id, name } = req.body
    id = Number(id)
    student = student.map((el) => (el.id === id ? { id, name } : el))
    res.redirect("/")
})

app.get("/", (req, res) => {
    res.render("home", { student, editStudent: null })
})

app.listen(6789, () => {
    console.log("server is running on http://localhost:6789")
})
